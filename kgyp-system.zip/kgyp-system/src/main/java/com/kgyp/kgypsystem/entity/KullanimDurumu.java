package com.kgyp.kgypsystem.entity;

public enum KullanimDurumu {
    SAHIBI_ATIL("Sahibi - Atıl"),
    SAHIBI_KIRAYA_VERILMIS("Sahibi - Kiraya Verilmiş"),
    KIRACISI("Kiracısı");

    private final String aciklama;

    KullanimDurumu(String aciklama) {
        this.aciklama = aciklama;
    }

    public String getAciklama() {
        return aciklama;
    }
}