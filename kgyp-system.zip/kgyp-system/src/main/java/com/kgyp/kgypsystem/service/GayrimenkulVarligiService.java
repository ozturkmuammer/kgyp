package com.kgyp.kgypsystem.service;

import com.kgyp.kgypsystem.entity.GayrimenkulVarligi;
import com.kgyp.kgypsystem.entity.KullanimDurumu;
import com.kgyp.kgypsystem.repository.GayrimenkulVarligiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class GayrimenkulVarligiService {

    @Autowired
    private GayrimenkulVarligiRepository repository;

    // Tüm gayrimenkulleri listele
    public List<GayrimenkulVarligi> tumGayrimenkulleriListele() {
        return repository.findAll();
    }

    // ID ile gayrimenkul bul
    public Optional<GayrimenkulVarligi> gayrimenkulBul(UUID id) {
        return repository.findById(id);
    }

    // Yeni gayrimenkul kaydet
    public GayrimenkulVarligi gayrimenkulKaydet(GayrimenkulVarligi gayrimenkul) {
        // Validasyon
        if (gayrimenkul.getAdres() == null || gayrimenkul.getAdres().trim().isEmpty()) {
            throw new IllegalArgumentException("Adres boş olamaz");
        }
        if (gayrimenkul.getSehir() == null || gayrimenkul.getSehir().trim().isEmpty()) {
            throw new IllegalArgumentException("Şehir boş olamaz");
        }

        return repository.save(gayrimenkul);
    }

    // Gayrimenkul güncelle
    public GayrimenkulVarligi gayrimenkulGuncelle(UUID id, GayrimenkulVarligi guncelGayrimenkul) {
        Optional<GayrimenkulVarligi> mevcut = repository.findById(id);
        if (mevcut.isPresent()) {
            GayrimenkulVarligi gayrimenkul = mevcut.get();

            // Güncelleme işlemleri
            if (guncelGayrimenkul.getAdres() != null) {
                gayrimenkul.setAdres(guncelGayrimenkul.getAdres());
            }
            if (guncelGayrimenkul.getSehir() != null) {
                gayrimenkul.setSehir(guncelGayrimenkul.getSehir());
            }
            if (guncelGayrimenkul.getIlce() != null) {
                gayrimenkul.setIlce(guncelGayrimenkul.getIlce());
            }
            if (guncelGayrimenkul.getTapuNo() != null) {
                gayrimenkul.setTapuNo(guncelGayrimenkul.getTapuNo());
            }
            if (guncelGayrimenkul.getBrutM2() != null) {
                gayrimenkul.setBrutM2(guncelGayrimenkul.getBrutM2());
            }
            if (guncelGayrimenkul.getNetM2() != null) {
                gayrimenkul.setNetM2(guncelGayrimenkul.getNetM2());
            }
            if (guncelGayrimenkul.getGoogleMapsLink() != null) {
                gayrimenkul.setGoogleMapsLink(guncelGayrimenkul.getGoogleMapsLink());
            }
            if (guncelGayrimenkul.getDegerlemeRaporuLink() != null) {
                gayrimenkul.setDegerlemeRaporuLink(guncelGayrimenkul.getDegerlemeRaporuLink());
            }
            if (guncelGayrimenkul.getKullanimDurumu() != null) {
                gayrimenkul.setKullanimDurumu(guncelGayrimenkul.getKullanimDurumu());
            }
            if (guncelGayrimenkul.getEnSonDegerlemeTarihi() != null) {
                gayrimenkul.setEnSonDegerlemeTarihi(guncelGayrimenkul.getEnSonDegerlemeTarihi());
            }
            if (guncelGayrimenkul.getEnSonDegerlemeTutari() != null) {
                gayrimenkul.setEnSonDegerlemeTutari(guncelGayrimenkul.getEnSonDegerlemeTutari());
            }

            return repository.save(gayrimenkul);
        } else {
            throw new RuntimeException("Gayrimenkul bulunamadı: " + id);
        }
    }

    // Gayrimenkul sil
    public void gayrimenkulSil(UUID id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("Silinecek gayrimenkul bulunamadı: " + id);
        }
    }

    // Şehre göre gayrimenkul ara
    public List<GayrimenkulVarligi> sehirGoureGayrimenkulAra(String sehir) {
        return repository.findBySehir(sehir);
    }

    // Kullanım durumuna göre gayrimenkul ara
    public List<GayrimenkulVarligi> kullanimDurumunaGoreAra(KullanimDurumu kullanimDurumu) {
        return repository.findByKullanimDurumu(kullanimDurumu);
    }

    // Adres içinde arama
    public List<GayrimenkulVarligi> adresIcindeAra(String arananKelime) {
        return repository.findByAdresContainingIgnoreCase(arananKelime);
    }

    // Belirli metrekareden büyük gayrimenkuller
    public List<GayrimenkulVarligi> buyukGayrimenkuller(Double minM2) {
        return repository.findByBrutM2GreaterThan(minM2);
    }

    // Değerleme raporu güncelle
    public GayrimenkulVarligi degerlemeRaporuGuncelle(UUID id, String raporLink,
                                                      BigDecimal tutar, LocalDate tarih) {
        Optional<GayrimenkulVarligi> gayrimenkul = repository.findById(id);
        if (gayrimenkul.isPresent()) {
            GayrimenkulVarligi varlık = gayrimenkul.get();
            varlık.setDegerlemeRaporuLink(raporLink);
            varlık.setEnSonDegerlemeTutari(tutar);
            varlık.setEnSonDegerlemeTarihi(tarih);
            return repository.save(varlık);
        } else {
            throw new RuntimeException("Gayrimenkul bulunamadı: " + id);
        }
    }

    // İstatistikler
    public long toplamGayrimenkulSayisi() {
        return repository.count();
    }

    public List<Object[]> sehirBazindaSayim() {
        return repository.countBySehir();
    }

    public List<Object[]> kullanimDurumuBazindaSayim() {
        return repository.countByKullanimDurumu();
    }
}