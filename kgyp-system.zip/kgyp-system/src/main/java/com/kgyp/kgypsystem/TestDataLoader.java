package com.kgyp.kgypsystem.config;

import com.kgyp.kgypsystem.entity.*;
import com.kgyp.kgypsystem.service.GayrimenkulVarligiService;
import com.kgyp.kgypsystem.service.SozlesmeService;
import com.kgyp.kgypsystem.service.BakimVeOnarimService;
import com.kgyp.kgypsystem.service.FinansalHareketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Component
public class TestDataLoader implements CommandLineRunner {

    @Autowired
    private GayrimenkulVarligiService gayrimenkulService;

    @Autowired
    private SozlesmeService sozlesmeService;

    @Autowired
    private BakimVeOnarimService bakimService;

    @Autowired
    private FinansalHareketService finansalService;

    @Override
    public void run(String... args) throws Exception {

        // Sadece ilk çalıştırmada veri yükle
        if (gayrimenkulService.toplamGayrimenkulSayisi() > 0) {
            System.out.println("Test verisi zaten mevcut, yükleme atlandı.");
            return;
        }

        System.out.println("🏗️ Test verisi yükleniyor...");

        // 1. GAYRİMENKUL VARLİKLARI
        UUID gayrimenkul1Id = createGayrimenkul1();
        UUID gayrimenkul2Id = createGayrimenkul2();
        UUID gayrimenkul3Id = createGayrimenkul3();

        // 2. SÖZLEŞMELER
        UUID sozlesme1Id = createSozlesme1(gayrimenkul1Id);
        UUID sozlesme2Id = createSozlesme2(gayrimenkul2Id);

        // 3. BAKIM İŞLERİ
        createBakimIsler(gayrimenkul1Id, gayrimenkul2Id, gayrimenkul3Id);

        // 4. FİNANSAL HAREKETLER
        createFinansalHareketler(gayrimenkul1Id, gayrimenkul2Id);

        System.out.println("✅ Test verisi başarıyla yüklendi!");
        System.out.println("📊 Dashboard: http://localhost:8080/api/dashboard/kpi");
        System.out.println("🏠 Gayrimenkuller: http://localhost:8080/api/gayrimenkul");
    }

    private UUID createGayrimenkul1() {
        GayrimenkulVarligi gayrimenkul = new GayrimenkulVarligi();
        gayrimenkul.setAdres("Bahçelievler Mah. 5. Cad. No:123 Daire:4");
        gayrimenkul.setSehir("İstanbul");
        gayrimenkul.setIlce("Bahçelievler");
        gayrimenkul.setTapuNo("123456789");
        gayrimenkul.setBrutM2(120.0);
        gayrimenkul.setNetM2(105.0);
        gayrimenkul.setKullanimDurumu(KullanimDurumu.SAHIBI_KIRAYA_VERILMIS);
        gayrimenkul.setEnSonDegerlemeTarihi(LocalDate.now().minusMonths(6));
        gayrimenkul.setEnSonDegerlemeTutari(new BigDecimal("850000"));
        gayrimenkul.setGoogleMapsLink("https://maps.google.com/?q=41.0082,28.9784");
        gayrimenkul.setDegerlemeRaporuLink("/documents/degerle_raporu_1.pdf");

        GayrimenkulVarligi saved = gayrimenkulService.gayrimenkulKaydet(gayrimenkul);
        return saved.getVarlikId();
    }

    private UUID createGayrimenkul2() {
        GayrimenkulVarligi gayrimenkul = new GayrimenkulVarligi();
        gayrimenkul.setAdres("Kadıköy Mah. Bağdat Cad. No:456 Daire:2");
        gayrimenkul.setSehir("İstanbul");
        gayrimenkul.setIlce("Kadıköy");
        gayrimenkul.setTapuNo("987654321");
        gayrimenkul.setBrutM2(95.0);
        gayrimenkul.setNetM2(85.0);
        gayrimenkul.setKullanimDurumu(KullanimDurumu.SAHIBI_KIRAYA_VERILMIS);
        gayrimenkul.setEnSonDegerlemeTarihi(LocalDate.now().minusMonths(3));
        gayrimenkul.setEnSonDegerlemeTutari(new BigDecimal("720000"));
        gayrimenkul.setGoogleMapsLink("https://maps.google.com/?q=40.9925,29.0265");

        GayrimenkulVarligi saved = gayrimenkulService.gayrimenkulKaydet(gayrimenkul);
        return saved.getVarlikId();
    }

    private UUID createGayrimenkul3() {
        GayrimenkulVarligi gayrimenkul = new GayrimenkulVarligi();
        gayrimenkul.setAdres("Çankaya Mah. Tunalı Hilmi Cad. No:789 Daire:8");
        gayrimenkul.setSehir("Ankara");
        gayrimenkul.setIlce("Çankaya");
        gayrimenkul.setTapuNo("456123789");
        gayrimenkul.setBrutM2(140.0);
        gayrimenkul.setNetM2(125.0);
        gayrimenkul.setKullanimDurumu(KullanimDurumu.SAHIBI_ATIL);
        gayrimenkul.setEnSonDegerlemeTarihi(LocalDate.now().minusMonths(12));
        gayrimenkul.setEnSonDegerlemeTutari(new BigDecimal("650000"));

        GayrimenkulVarligi saved = gayrimenkulService.gayrimenkulKaydet(gayrimenkul);
        return saved.getVarlikId();
    }

    private UUID createSozlesme1(UUID gayrimenkulId) {
        Sozlesme sozlesme = new Sozlesme();
        sozlesme.setKiraciAdi("Ahmet Yılmaz");
        sozlesme.setKiralayanAdi("Mehmet Özkan");
        sozlesme.setSozlesmeBaslangicTarihi(LocalDate.of(2024, 1, 1));
        sozlesme.setSozlesmeBitisTarihi(LocalDate.of(2025, 12, 31));
        sozlesme.setAylikKiraTutari(new BigDecimal("15000"));
        sozlesme.setKiraArtisMetodu(KiraArtisMetodu.TUFE);
        sozlesme.setKiraOdemeGunu(5);
        sozlesme.setDepozito(new BigDecimal("30000"));
        sozlesme.setNotlar("İlk kiracı. Güvenilir kişi.");
        sozlesme.setKiraArtisiYapildi2025(false);

        Sozlesme saved = sozlesmeService.sozlesmeKaydet(gayrimenkulId, sozlesme);
        return saved.getSozlesmeId();
    }

    private UUID createSozlesme2(UUID gayrimenkulId) {
        Sozlesme sozlesme = new Sozlesme();
        sozlesme.setKiraciAdi("Ayşe Demir");
        sozlesme.setKiralayanAdi("Fatma Kaya");
        sozlesme.setSozlesmeBaslangicTarihi(LocalDate.of(2023, 6, 1));
        sozlesme.setSozlesmeBitisTarihi(LocalDate.of(2025, 5, 31));
        sozlesme.setAylikKiraTutari(new BigDecimal("12500"));
        sozlesme.setKiraArtisMetodu(KiraArtisMetodu.SABIT);
        sozlesme.setSabitArtisOrani(new BigDecimal("10"));
        sozlesme.setKiraOdemeGunu(1);
        sozlesme.setDepozito(new BigDecimal("25000"));
        sozlesme.setNotlar("Uzun süreli kiracı.");
        sozlesme.setKiraArtisiYapildi2025(true);

        Sozlesme saved = sozlesmeService.sozlesmeKaydet(gayrimenkulId, sozlesme);
        return saved.getSozlesmeId();
    }

    private void createBakimIsler(UUID gayrimenkul1Id, UUID gayrimenkul2Id, UUID gayrimenkul3Id) {
        // Aktif bakım - Kritik
        BakimVeOnarim bakim1 = new BakimVeOnarim();
        bakim1.setBaslik("Su kaçağı tamiri");
        bakim1.setAciklama("Banyo bataryasından su sızıntısı var. Acil müdahale gerekiyor.");
        bakim1.setKategori(BakimVeOnarim.BakimKategorisi.TESISATI);
        bakim1.setOncelik(BakimVeOnarim.OncelikSeviyesi.KRITIK);
        bakim1.setDurum(BakimVeOnarim.BakimDurumu.DEVAM_EDIYOR);
        bakim1.setBaslangicTarihi(LocalDateTime.now().minusDays(2));
        bakim1.setPlanlananBitisTarihi(LocalDateTime.now().plusDays(1));
        bakim1.setTahminiMaliyet(new BigDecimal("2500"));
        bakim1.setSorumluPersonel("Ali Tesisat");
        bakim1.setTedarikciFirma("Hızır Tesisat Ltd.");
        bakim1.setTedarikciTelefon("0212 555 0101");
        bakim1.setOlusturanKullanici("admin");
        bakimService.bakimKaydet(gayrimenkul1Id, bakim1);

        // Planlanan bakım
        BakimVeOnarim bakim2 = new BakimVeOnarim();
        bakim2.setBaslik("Dış cephe boyası");
        bakim2.setAciklama("Dış cephe boyası yenilenecek. 3 kat boya uygulanacak.");
        bakim2.setKategori(BakimVeOnarim.BakimKategorisi.BOYAMA);
        bakim2.setOncelik(BakimVeOnarim.OncelikSeviyesi.ORTA);
        bakim2.setDurum(BakimVeOnarim.BakimDurumu.PLANLANMIS);
        bakim2.setBaslangicTarihi(LocalDateTime.now().plusDays(7));
        bakim2.setPlanlananBitisTarihi(LocalDateTime.now().plusDays(14));
        bakim2.setTahminiMaliyet(new BigDecimal("8500"));
        bakim2.setSorumluPersonel("Mehmet Boyacı");
        bakim2.setTedarikciFirma("Renk Boya İnş.");
        bakim2.setOlusturanKullanici("admin");
        bakimService.bakimKaydet(gayrimenkul2Id, bakim2);

        // Tamamlanmış bakım
        BakimVeOnarim bakim3 = new BakimVeOnarim();
        bakim3.setBaslik("Elektrik revizyonu");
        bakim3.setAciklama("Eski elektrik tesisatı yenilendi. Sigorta panosu değiştirildi.");
        bakim3.setKategori(BakimVeOnarim.BakimKategorisi.ELEKTRIK);
        bakim3.setOncelik(BakimVeOnarim.OncelikSeviyesi.YUKSEK);
        bakim3.setDurum(BakimVeOnarim.BakimDurumu.TAMAMLANDI);
        bakim3.setBaslangicTarihi(LocalDateTime.now().minusDays(10));
        bakim3.setPlanlananBitisTarihi(LocalDateTime.now().minusDays(3));
        bakim3.setGercekBitisTarihi(LocalDateTime.now().minusDays(2));
        bakim3.setTahminiMaliyet(new BigDecimal("4500"));
        bakim3.setGercekMaliyet(new BigDecimal("4750"));
        bakim3.setSorumluPersonel("Elektrikçi Hasan");
        bakim3.setTedarikciFirma("Voltaj Elektrik");
        bakim3.setGarantiSuresiAy(12);
        bakim3.setOlusturanKullanici("admin");
        bakimService.bakimKaydet(gayrimenkul3Id, bakim3);
    }

    private void createFinansalHareketler(UUID gayrimenkul1Id, UUID gayrimenkul2Id) {
        // Kira gelirleri
        FinansalHareket kira1 = new FinansalHareket();
        kira1.setHareketTipi(FinansalHareket.HareketTipi.KIRA_GELIRI);
        kira1.setTutar(new BigDecimal("15000"));
        kira1.setAciklama("Ocak 2025 kira ödemesi - Ahmet Yılmaz");
        kira1.setKiraDonemi("2025-01");
        kira1.setOdemeYontemi(FinansalHareket.OdemeYontemi.BANKA_HAVALESI);
        kira1.setOnaylanmis(true);
        kira1.setOnaylayanKullanici("admin");
        kira1.setOnayTarihi(LocalDateTime.now().minusDays(5));
        finansalService.hareketKaydet(gayrimenkul1Id, kira1);

        FinansalHareket kira2 = new FinansalHareket();
        kira2.setHareketTipi(FinansalHareket.HareketTipi.KIRA_GELIRI);
        kira2.setTutar(new BigDecimal("12500"));
        kira2.setAciklama("Ocak 2025 kira ödemesi - Ayşe Demir");
        kira2.setKiraDonemi("2025-01");
        kira2.setOdemeYontemi(FinansalHareket.OdemeYontemi.NAKIT);
        kira2.setOnaylanmis(true);
        kira2.setOnaylayanKullanici("admin");
        finansalService.hareketKaydet(gayrimenkul2Id, kira2);

        // Giderler
        FinansalHareket gider1 = new FinansalHareket();
        gider1.setHareketTipi(FinansalHareket.HareketTipi.BAKIM_ONARIM);
        gider1.setTutar(new BigDecimal("4750"));
        gider1.setAciklama("Elektrik revizyonu maliyeti");
        gider1.setOdemeYontemi(FinansalHareket.OdemeYontemi.BANKA_HAVALESI);
        gider1.setTedarikci("Voltaj Elektrik");
        gider1.setFaturaNo("VE-2024-156");
        gider1.setOnaylanmis(true);
        gider1.setOnaylayanKullanici("admin");
        finansalService.hareketKaydet(gayrimenkul1Id, gider1);

        // Onay bekleyen hareket
        FinansalHareket bekleyen = new FinansalHareket();
        bekleyen.setHareketTipi(FinansalHareket.HareketTipi.SIGORTA);
        bekleyen.setTutar(new BigDecimal("1200"));
        bekleyen.setAciklama("Yıllık bina sigortası primi");
        bekleyen.setOdemeYontemi(FinansalHareket.OdemeYontemi.KREDI_KARTI);
        bekleyen.setTedarikci("ABC Sigorta");
        bekleyen.setOnaylanmis(false);
        finansalService.hareketKaydet(gayrimenkul1Id, bekleyen);
    }
}