package com.kgyp.kgypsystem.repository;

import com.kgyp.kgypsystem.entity.FinansalHareket;
import com.kgyp.kgypsystem.entity.FinansalHareket.HareketTipi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface FinansalHareketRepository extends JpaRepository<FinansalHareket, UUID> {

    // Gayrimenkul ID'sine göre finansal hareketler
    List<FinansalHareket> findByGayrimenkulVarligi_VarlikId(UUID varlikId);

    // Hareket tipine göre filtreleme
    List<FinansalHareket> findByHareketTipi(HareketTipi hareketTipi);

    // Tarih aralığına göre hareketler
    @Query("SELECT f FROM FinansalHareket f WHERE f.hareketTarihi BETWEEN :baslangic AND :bitis")
    List<FinansalHareket> findByTarihAraliginda(
            @Param("baslangic") LocalDateTime baslangic,
            @Param("bitis") LocalDateTime bitis
    );

    // Onay bekleyen hareketler
    List<FinansalHareket> findByOnaylanmisFalse();

    // Belirli bir döneme ait kira gelirleri
    @Query("SELECT f FROM FinansalHareket f WHERE f.kiraDonemi = :donem AND f.hareketTipi = 'KIRA_GELIRI'")
    List<FinansalHareket> findKiraGeliriByDonem(@Param("donem") String donem);

    // Toplam gelir hesaplama
    @Query("SELECT SUM(f.tutar) FROM FinansalHareket f WHERE f.hareketTipi IN ('KIRA_GELIRI', 'DEPOZITO_ALINDI', 'DIGER_GELIR') AND f.onaylanmis = true")
    BigDecimal toplamGelir();

    // Toplam gider hesaplama
    @Query("SELECT SUM(f.tutar) FROM FinansalHareket f WHERE f.hareketTipi NOT IN ('KIRA_GELIRI', 'DEPOZITO_ALINDI', 'DIGER_GELIR') AND f.onaylanmis = true")
    BigDecimal toplamGider();

    // Son hareketler (en son 10 hareket)
    @Query("SELECT f FROM FinansalHareket f ORDER BY f.hareketTarihi DESC")
    List<FinansalHareket> findTop10ByOrderByHareketTarihiDesc();

    // Tedarikci bazında giderler
    List<FinansalHareket> findByTedarikciContainingIgnoreCase(String tedarikci);

    // Aylık kira geliri raporu
    @Query("SELECT f.kiraDonemi, SUM(f.tutar) FROM FinansalHareket f WHERE f.hareketTipi = 'KIRA_GELIRI' AND f.onaylanmis = true GROUP BY f.kiraDonemi ORDER BY f.kiraDonemi")
    List<Object[]> aylikKiraGeliriRaporu();

    // Hareket tipi bazında toplam tutarlar
    @Query("SELECT f.hareketTipi, SUM(f.tutar) FROM FinansalHareket f WHERE f.onaylanmis = true GROUP BY f.hareketTipi")
    List<Object[]> hareketTipiBazindaToplam();
}