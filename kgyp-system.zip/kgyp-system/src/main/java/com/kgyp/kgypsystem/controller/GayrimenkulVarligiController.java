package com.kgyp.kgypsystem.controller;

import com.kgyp.kgypsystem.entity.GayrimenkulVarligi;
import com.kgyp.kgypsystem.entity.KullanimDurumu;
import com.kgyp.kgypsystem.service.GayrimenkulVarligiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/gayrimenkul")
@CrossOrigin(origins = "*") // Frontend entegrasyonu için
public class GayrimenkulVarligiController {

    @Autowired
    private GayrimenkulVarligiService service;

    // Tüm gayrimenkulleri listele
    @GetMapping
    public ResponseEntity<List<GayrimenkulVarligi>> tumGayrimenkulleriListele() {
        List<GayrimenkulVarligi> gayrimenkuller = service.tumGayrimenkulleriListele();
        return ResponseEntity.ok(gayrimenkuller);
    }

    // ID ile gayrimenkul getir
    @GetMapping("/{id}")
    public ResponseEntity<GayrimenkulVarligi> gayrimenkulGetir(@PathVariable UUID id) {
        Optional<GayrimenkulVarligi> gayrimenkul = service.gayrimenkulBul(id);
        if (gayrimenkul.isPresent()) {
            return ResponseEntity.ok(gayrimenkul.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Yeni gayrimenkul oluştur
    @PostMapping
    public ResponseEntity<GayrimenkulVarligi> gayrimenkulOlustur(@RequestBody GayrimenkulVarligi gayrimenkul) {
        try {
            GayrimenkulVarligi yeniGayrimenkul = service.gayrimenkulKaydet(gayrimenkul);
            return ResponseEntity.status(HttpStatus.CREATED).body(yeniGayrimenkul);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // Gayrimenkul güncelle
    @PutMapping("/{id}")
    public ResponseEntity<GayrimenkulVarligi> gayrimenkulGuncelle(
            @PathVariable UUID id,
            @RequestBody GayrimenkulVarligi gayrimenkul) {
        try {
            GayrimenkulVarligi guncelGayrimenkul = service.gayrimenkulGuncelle(id, gayrimenkul);
            return ResponseEntity.ok(guncelGayrimenkul);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Gayrimenkul sil
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> gayrimenkulSil(@PathVariable UUID id) {
        try {
            service.gayrimenkulSil(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Şehre göre arama
    @GetMapping("/sehir/{sehir}")
    public ResponseEntity<List<GayrimenkulVarligi>> sehirGoureAra(@PathVariable String sehir) {
        List<GayrimenkulVarligi> gayrimenkuller = service.sehirGoureGayrimenkulAra(sehir);
        return ResponseEntity.ok(gayrimenkuller);
    }

    // Kullanım durumuna göre arama
    @GetMapping("/kullanim-durumu/{kullanimDurumu}")
    public ResponseEntity<List<GayrimenkulVarligi>> kullanimDurumunaGoreAra(
            @PathVariable KullanimDurumu kullanimDurumu) {
        List<GayrimenkulVarligi> gayrimenkuller = service.kullanimDurumunaGoreAra(kullanimDurumu);
        return ResponseEntity.ok(gayrimenkuller);
    }

    // Adres içinde arama
    @GetMapping("/ara")
    public ResponseEntity<List<GayrimenkulVarligi>> adresIcindeAra(
            @RequestParam String kelime) {
        List<GayrimenkulVarligi> gayrimenkuller = service.adresIcindeAra(kelime);
        return ResponseEntity.ok(gayrimenkuller);
    }

    // Belirli metrekareden büyük gayrimenkuller
    @GetMapping("/buyuk-gayrimenkuller")
    public ResponseEntity<List<GayrimenkulVarligi>> buyukGayrimenkuller(
            @RequestParam Double minM2) {
        List<GayrimenkulVarligi> gayrimenkuller = service.buyukGayrimenkuller(minM2);
        return ResponseEntity.ok(gayrimenkuller);
    }

    // Değerleme raporu güncelleme
    @PutMapping("/{id}/degerleme")
    public ResponseEntity<GayrimenkulVarligi> degerlemeRaporuGuncelle(
            @PathVariable UUID id,
            @RequestParam String raporLink,
            @RequestParam BigDecimal tutar,
            @RequestParam String tarih) {
        try {
            LocalDate degerlemetarihi = LocalDate.parse(tarih);
            GayrimenkulVarligi guncelGayrimenkul = service.degerlemeRaporuGuncelle(
                    id, raporLink, tutar, degerlemetarihi);
            return ResponseEntity.ok(guncelGayrimenkul);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // İstatistikler endpoint'i
    @GetMapping("/istatistikler")
    public ResponseEntity<Object> istatistikler() {
        // Basit istatistik bilgileri döndür
        long toplamSayi = service.toplamGayrimenkulSayisi();
        List<Object[]> sehirSayimi = service.sehirBazindaSayim();
        List<Object[]> kullanimSayimi = service.kullanimDurumuBazindaSayim();

        // Basit bir Map yapısı oluştur
        var istatistikler = new java.util.HashMap<String, Object>();
        istatistikler.put("toplamGayrimenkulSayisi", toplamSayi);
        istatistikler.put("sehirBazindaSayim", sehirSayimi);
        istatistikler.put("kullanimDurumuBazindaSayim", kullanimSayimi);

        return ResponseEntity.ok(istatistikler);
    }

    // Kullanım durumu enum değerlerini listele
    @GetMapping("/kullanim-durumlari")
    public ResponseEntity<KullanimDurumu[]> kullanimDurumlari() {
        return ResponseEntity.ok(KullanimDurumu.values());
    }
}