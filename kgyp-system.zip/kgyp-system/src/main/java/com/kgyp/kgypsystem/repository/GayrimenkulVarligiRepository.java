package com.kgyp.kgypsystem.repository;

import com.kgyp.kgypsystem.entity.GayrimenkulVarligi;
import com.kgyp.kgypsystem.entity.KullanimDurumu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface GayrimenkulVarligiRepository extends JpaRepository<GayrimenkulVarligi, UUID> {

    // Şehre göre gayrimenkul arama
    List<GayrimenkulVarligi> findBySehir(String sehir);

    // Kullanım durumuna göre arama
    List<GayrimenkulVarligi> findByKullanimDurumu(KullanimDurumu kullanimDurumu);

    // Şehir ve kullanım durumuna göre arama
    List<GayrimenkulVarligi> findBySehirAndKullanimDurumu(String sehir, KullanimDurumu kullanimDurumu);

    // Adres içinde kelime arama (case insensitive)
    List<GayrimenkulVarligi> findByAdresContainingIgnoreCase(String adresKelimesi);

    // Belirli metrekareden büyük gayrimenkuller
    @Query("SELECT g FROM GayrimenkulVarligi g WHERE g.brutM2 > :minM2")
    List<GayrimenkulVarligi> findByBrutM2GreaterThan(@Param("minM2") Double minM2);

    // Değerleme raporu olan gayrimenkuller
    List<GayrimenkulVarligi> findByDegerlemeRaporuLinkIsNotNull();

    // Google Maps linki olan gayrimenkuller
    List<GayrimenkulVarligi> findByGoogleMapsLinkIsNotNull();

    // Şehir bazında sayım
    @Query("SELECT g.sehir, COUNT(g) FROM GayrimenkulVarligi g GROUP BY g.sehir")
    List<Object[]> countBySehir();

    // Kullanım durumu bazında sayım
    @Query("SELECT g.kullanimDurumu, COUNT(g) FROM GayrimenkulVarligi g GROUP BY g.kullanimDurumu")
    List<Object[]> countByKullanimDurumu();
}