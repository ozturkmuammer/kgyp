package com.kgyp.kgypsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KgypSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(KgypSystemApplication.class, args);
    }

}
