package com.kgyp.kgypsystem.controller;

import com.kgyp.kgypsystem.service.BakimVeOnarimService;
import com.kgyp.kgypsystem.service.FinansalHareketService;
import com.kgyp.kgypsystem.service.GayrimenkulVarligiService;
import com.kgyp.kgypsystem.service.SozlesmeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private GayrimenkulVarligiService gayrimenkulService;

    @Autowired
    private SozlesmeService sozlesmeService;

    @Autowired
    private BakimVeOnarimService bakimService;

    @Autowired
    private FinansalHareketService finansalService;

    /**
     * Ana Dashboard KPI'larını getir
     */
    @GetMapping("/kpi")
    public ResponseEntity<Map<String, Object>> dashboardKPI() {
        Map<String, Object> kpi = new HashMap<>();

        // Gayrimenkul sayıları
        long toplamGayrimenkul = gayrimenkulService.toplamGayrimenkulSayisi();
        long aktifSozlesme = sozlesmeService.aktifSozlesmeleriListele().size();
        double dolulukOrani = toplamGayrimenkul > 0 ? (double) aktifSozlesme / toplamGayrimenkul * 100 : 0;
        kpi.put("toplamGayrimenkul", toplamGayrimenkul);
        kpi.put("aktifSozlesme", aktifSozlesme);
        kpi.put("dolulukOrani", Math.round(dolulukOrani * 100.0) / 100.0);

        // Finansal bilgiler
        Double toplamKira = sozlesmeService.toplamAylikKiraGeliri();
        Double ortalamaKira = aktifSozlesme > 0 ? toplamKira / aktifSozlesme : 0;
        kpi.put("toplamAylikKira", Math.round(ortalamaKira * 100.0) / 100.0);
        kpi.put("ortalamaAylikKira", Math.round(ortalamaKira * 100.0) / 100.0);

        // Bakım durumu (basit metrik)
        var buHaftaBakimlar = bakimService.buHaftaBaslayacakBakimlar();
        kpi.put("buHaftaBaslayacakBakimSayisi", buHaftaBakimlar.size());

        // Sistem sağlık durumu (basit metrik)
        int saglikSkoru = 100;
        if (gecikenBakimlar().size() > 5) saglikSkoru -= 20;
        if (yakindaBitecekler().size() > 3) saglikSkoru -= 15;
        if (onayBekleyenler().size() > 10) saglikSkoru -= 10;
        kpi.put("sistemSaglikSkoru", Math.max(saglikSkoru, 0));

        return ResponseEntity.ok(kpi);
    }

    /**
     * Son aktiviteleri getir
     */
    @GetMapping("/son-aktiviteler")
    public ResponseEntity<Map<String, Object>> sonAktiviteler() {
        Map<String, Object> aktiviteler = new HashMap<>();

        // Son eklenen gayrimenkuller (son 5)
        var tumGayrimenkuller = gayrimenkulService.tumGayrimenkulleriListele();
        var sonGayrimenkuller = tumGayrimenkuller.stream()
                .limit(5)
                .toList();
        aktiviteler.put("sonGayrimenkuller", sonGayrimenkuller);

        // Son sözleşmeler (son 5)
        var tumSozlesmeler = sozlesmeService.tumSozlesmeleriListele();
        var sonSozlesmeler = tumSozlesmeler.stream()
                .limit(5)
                .toList();
        aktiviteler.put("sonSozlesmeler", sonSozlesmeler);

        // Son bakım işleri
        var sonBakimlar = bakimService.sonEklenenBakimlar();
        aktiviteler.put("sonBakimlar", sonBakimlar);

        // Son finansal hareketler
        var sonHareketler = finansalService.sonHareketler();
        aktiviteler.put("sonFinansalHareketler", sonHareketler);

        return ResponseEntity.ok(aktiviteler);
    }

    /**
     * Kritik uyarıları getir
     */
    @GetMapping("/uyarilar")
    public ResponseEntity<Map<String, Object>> kritikUyarilar() {
        Map<String, Object> uyarilar = new HashMap<>();

        // Yakında bitecek sözleşmeler
        var yakindaBitenler = sozlesmeService.yakindaSuresiDolacakSozlesmeler();
        uyarilar.put("yakindaBitenSozlesmeler", yakindaBitenler);

        // Geciken bakım işleri
        var gecikenBakimlar = bakimService.gecikenBakimlar();
        uyarilar.put("gecikenBakimlar", gecikenBakimlar);

        // Kritik bakım işleri
        var kritikBakimlar = bakimService.kritikBakimlar();
        uyarilar.put("kritikBakimlar", kritikBakimlar);

        // Onay bekleyen finansal hareketler
        var onayBekleyenler = finansalService.onayBekleyenHareketler();
        uyarilar.put("onayBekleyenHareketler", onayBekleyenler);

        // Kira artışı yapılmamış sözleşmeler
        var kiraArtisiGerekenler = sozlesmeService.kiraArtisiYapilmamisSozlesmeler();
        uyarilar.put("kiraArtisiGerekenler", kiraArtisiGerekenler);

        return ResponseEntity.ok(uyarilar);
    }

    /**
     * Hızlı istatistikler
     */
    @GetMapping("/istatistikler")
    public ResponseEntity<Map<String, Object>> hizliIstatistikler() {
        Map<String, Object> istatistikler = new HashMap<>();

        // Şehir bazında dağılım
        var sehirDagilimi = gayrimenkulService.sehirBazindaSayim();
        istatistikler.put("sehirDagilimi", sehirDagilimi);

        // Kullanım durumu dağılımı
        var kullanimDagilimi = gayrimenkulService.kullanimDurumuBazindaSayim();
        istatistikler.put("kullanimDagilimi", kullanimDagilimi);

        // Bakım kategorisi dağılımı
        var bakimKategorileri = bakimService.kategoriBazindaBakimSayisi();
        istatistikler.put("bakimKategorileri", bakimKategorileri);

        // Mali özet
        var maliOzet = finansalService.maliOzetHesapla();
        istatistikler.put("maliOzet", maliOzet);

        return ResponseEntity.ok(istatistikler);
    }

    /**
     * Bu ayki özet bilgiler
     */
    @GetMapping("/bu-ay-ozet")
    public ResponseEntity<Map<String, Object>> buAyOzet() {
        Map<String, Object> ozet = new HashMap<>();

        // Bu ayki finansal durum
        LocalDateTime ayBaslangic = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0);
        LocalDateTime ayBitis = ayBaslangic.plusMonths(1).minusSeconds(1);

        var buAyHareketler = finansalService.tarihAraligindaHareketler(ayBaslangic, ayBitis);

        BigDecimal buAyGelir = buAyHareketler.stream()
                .filter(h -> h.getOnaylanmis() && h.isGelir())
                .map(h -> h.getTutar())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal buAyGider = buAyHareketler.stream()
                .filter(h -> h.getOnaylanmis() && h.isGider())
                .map(h -> h.getTutar())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        ozet.put("buAyGelir", buAyGelir);
        ozet.put("buAyGider", buAyGider);
        ozet.put("buAyNetKar", buAyGelir.subtract(buAyGider));

        // Bu ay tamamlanan bakımlar
        var buAyBakimlar = bakimService.tarihAraligindaTamamlananBakimlar(ayBaslangic, ayBitis);
        ozet.put("buAyTamamlananBakimSayisi", buAyBakimlar.size());

        return ResponseEntity.ok(ozet);
    }

    /**
     * Dashboard için gereken tüm verileri tek seferde getir
     */
    @GetMapping("/tum-veriler")
    public ResponseEntity<Map<String, Object>> tumDashboardVerileri() {
        Map<String, Object> tumVeriler = new HashMap<>();

        // Tüm KPI'ları dahil et
        tumVeriler.put("kpi", dashboardKPI().getBody());
        tumVeriler.put("sonAktiviteler", sonAktiviteler().getBody());
        tumVeriler.put("uyarilar", kritikUyarilar().getBody());
        tumVeriler.put("istatistikler", hizliIstatistikler().getBody());
        tumVeriler.put("buAyOzet", buAyOzet().getBody());

        return ResponseEntity.ok(tumVeriler);
    }

    // ==================== YARDIMCI METODLAR ====================

    private List<?> gecikenBakimlar() {
        return bakimService.gecikenBakimlar();
    }

    private List<?> yakindaBitecekler() {
        return sozlesmeService.yakindaSuresiDolacakSozlesmeler();
    }

    private List<?> onayBekleyenler() {
        return finansalService.onayBekleyenHareketler();
    }

    /**
     * Sistem durumu kontrolü
     */
    @GetMapping("/sistem-durumu")
    public ResponseEntity<Map<String, Object>> sistemDurumu() {
        Map<String, Object> durum = new HashMap<>();

        try {
            // Database bağlantısı test et
            long gayrimenkulSayisi = gayrimenkulService.toplamGayrimenkulSayisi();
            durum.put("databaseBaglantisi", "BAŞARILI");
            durum.put("toplamVeri", gayrimenkulSayisi);

            // Servis durumları
            durum.put("gayrimenkulService", "AKTIF");
            durum.put("sozlesmeService", "AKTIF");
            durum.put("bakimService", "AKTIF");
            durum.put("finansalService", "AKTIF");

            durum.put("sistemDurumu", "SAĞLIKLI");
            durum.put("sonKontrolZamani", LocalDateTime.now());

        } catch (Exception e) {
            durum.put("databaseBaglantisi", "HATA");
            durum.put("sistemDurumu", "SORUNLU");
            durum.put("hataDetayi", e.getMessage());
        }

        return ResponseEntity.ok(durum);
    }
}