package com.kgyp.kgypsystem.repository;

import com.kgyp.kgypsystem.entity.Sozlesme;
import com.kgyp.kgypsystem.entity.KiraArtisMetodu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface SozlesmeRepository extends JpaRepository<Sozlesme, UUID> {

    // Aktif sozlesmeleri getir
    List<Sozlesme> findByAktifMiTrue();

    // Gayrimenkul ID'sine gore sozlesmeler
    List<Sozlesme> findByGayrimenkulVarligi_VarlikId(UUID varlikId);

    // Kiraci adina gore arama
    List<Sozlesme> findByKiraciAdiContainingIgnoreCase(String kiraciAdi);

    // Belli bir tarih araliginda biten sozlesmeler
    @Query("SELECT s FROM Sozlesme s WHERE s.sozlesmeBitisTarihi BETWEEN :baslangic AND :bitis AND s.aktifMi = true")
    List<Sozlesme> findByBitisTarihiAraliginda(@Param("baslangic") LocalDate baslangic, @Param("bitis") LocalDate bitis);

    // Yakinda bitecek sozlesmeler (30 gun icerisinde)
    @Query("SELECT s FROM Sozlesme s WHERE s.sozlesmeBitisTarihi <= :tarih AND s.aktifMi = true")
    List<Sozlesme> findYakindaBitecekSozlesmeler(@Param("tarih") LocalDate tarih);

    // Kira artisi yapilmamis sozlesmeler
    @Query("SELECT s FROM Sozlesme s WHERE s.kiraArtisiYapildi2025 = false AND s.aktifMi = true")
    List<Sozlesme> findByKiraArtisiYapildi2025FalseAndAktifMiTrue();

    // Kira artis metoduna gore sozlesmeler
    List<Sozlesme> findByKiraArtisMetodu(KiraArtisMetodu metod);

    // Bugunku kira odeme gunune gore sozlesmeler
    @Query("SELECT s FROM Sozlesme s WHERE s.kiraOdemeGunu = :gun AND s.aktifMi = true")
    List<Sozlesme> findByKiraOdemeGunu(@Param("gun") Integer gun);

    // Toplam kira tutari hesaplama
    @Query("SELECT COALESCE(SUM(s.aylikKiraTutari), 0) FROM Sozlesme s WHERE s.aktifMi = true")
    Double toplamAylikKiraGeliri();

    // Sozlesme sayisi
    long countByAktifMiTrue();
}