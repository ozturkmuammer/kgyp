package com.kgyp.kgypsystem.repository;

import com.kgyp.kgypsystem.entity.BakimVeOnarim;
import com.kgyp.kgypsystem.entity.BakimVeOnarim.BakimDurumu;
import com.kgyp.kgypsystem.entity.BakimVeOnarim.BakimKategorisi;
import com.kgyp.kgypsystem.entity.BakimVeOnarim.OncelikSeviyesi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface BakimVeOnarimRepository extends JpaRepository<BakimVeOnarim, UUID> {

    // Gayrimenkul ID'sine göre bakım işleri
    List<BakimVeOnarim> findByGayrimenkulVarligi_VarlikId(UUID varlikId);

    // Duruma göre bakım işleri
    List<BakimVeOnarim> findByDurum(BakimDurumu durum);

    // Aktif bakım işleri (tamamlanmamış)
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.durum NOT IN ('TAMAMLANDI', 'IPTAL_EDILDI')")
    List<BakimVeOnarim> findAktifBakimlar();

    // Öncelik seviyesine göre bakım işleri
    List<BakimVeOnarim> findByOncelik(OncelikSeviyesi oncelik);

    // Kategoriye göre bakım işleri
    List<BakimVeOnarim> findByKategori(BakimKategorisi kategori);

    // Geciken bakım işleri
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.planlananBitisTarihi < :simdikiZaman AND b.durum NOT IN ('TAMAMLANDI', 'IPTAL_EDILDI')")
    List<BakimVeOnarim> findGecikenBakimlar(@Param("simdikiZaman") LocalDateTime simdikiZaman);

    // Kritik öncelikli ve geciken bakımlar
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.oncelik = 'KRITIK' AND b.durum NOT IN ('TAMAMLANDI', 'IPTAL_EDILDI')")
    List<BakimVeOnarim> findKritikBakimlar();

    // Sorumlu personele göre bakım işleri
    List<BakimVeOnarim> findBySorumluPersonelContainingIgnoreCase(String sorumluPersonel);

    // Tedarikci firmaya göre bakım işleri
    List<BakimVeOnarim> findByTedarikciFirmaContainingIgnoreCase(String tedarikciFirma);

    // Tarih aralığında tamamlanan bakımlar
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.gercekBitisTarihi BETWEEN :baslangic AND :bitis AND b.durum = 'TAMAMLANDI'")
    List<BakimVeOnarim> findTamamlananBakimlarByTarihAraligi(
            @Param("baslangic") LocalDateTime baslangic,
            @Param("bitis") LocalDateTime bitis
    );

    // Bu hafta başlayacak bakım işleri
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.baslangicTarihi BETWEEN :haftaBaslangici AND :haftaBitisi AND b.durum = 'PLANLANMIS'")
    List<BakimVeOnarim> findBuHaftaBaslayacakBakimlar(
            @Param("haftaBaslangici") LocalDateTime haftaBaslangici,
            @Param("haftaBitisi") LocalDateTime haftaBitisi
    );

    // Toplam bakım maliyeti hesaplama
    @Query("SELECT SUM(b.gercekMaliyet) FROM BakimVeOnarim b WHERE b.durum = 'TAMAMLANDI' AND b.gercekMaliyet IS NOT NULL")
    BigDecimal toplamBakimMaliyeti();

    // Kategori bazında bakım sayısı
    @Query("SELECT b.kategori, COUNT(b) FROM BakimVeOnarim b GROUP BY b.kategori")
    List<Object[]> kategoriBazindaBakimSayisi();

    // Durum bazında bakım sayısı
    @Query("SELECT b.durum, COUNT(b) FROM BakimVeOnarim b GROUP BY b.durum")
    List<Object[]> durumBazindaBakimSayisi();

    // Garanide olan bakım işleri
    @Query("SELECT b FROM BakimVeOnarim b WHERE b.garantiBitisTarihi > :simdikiZaman AND b.durum = 'TAMAMLANDI'")
    List<BakimVeOnarim> findGarantideOlanBakimlar(@Param("simdikiZaman") LocalDateTime simdikiZaman);

    // Arama fonksiyonu - başlık ve açıklamada arama
    @Query("SELECT b FROM BakimVeOnarim b WHERE LOWER(b.baslik) LIKE LOWER(CONCAT('%', :arama, '%')) OR LOWER(b.aciklama) LIKE LOWER(CONCAT('%', :arama, '%'))")
    List<BakimVeOnarim> findByBaslikOrAciklamaContaining(@Param("arama") String arama);

    // Son eklenen bakım işleri
    List<BakimVeOnarim> findTop10ByOrderByOlusturmaTarihiDesc();
}