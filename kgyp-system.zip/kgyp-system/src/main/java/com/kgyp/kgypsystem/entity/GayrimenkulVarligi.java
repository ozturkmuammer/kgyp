package com.kgyp.kgypsystem.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "gayrimenkul_varliklari")
public class GayrimenkulVarligi {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID varlikId;

    @Column(nullable = false)
    private String adres;

    private String googleMapsLink;
    private String sehir;
    private String ilce;
    private String tapuNo;
    private Double brutM2;
    private Double netM2;
    private String degerlemeRaporuLink;

    @Enumerated(EnumType.STRING)
    private KullanimDurumu kullanimDurumu;

    private LocalDate enSonDegerlemeTarihi;
    private BigDecimal enSonDegerlemeTutari;

    // Constructors
    public GayrimenkulVarligi() {}

    public GayrimenkulVarligi(String adres, String sehir) {
        this.adres = adres;
        this.sehir = sehir;
    }

    // Getters and Setters
    public UUID getVarlikId() { return varlikId; }
    public void setVarlikId(UUID varlikId) { this.varlikId = varlikId; }

    public String getAdres() { return adres; }
    public void setAdres(String adres) { this.adres = adres; }

    public String getGoogleMapsLink() { return googleMapsLink; }
    public void setGoogleMapsLink(String googleMapsLink) { this.googleMapsLink = googleMapsLink; }

    public String getSehir() { return sehir; }
    public void setSehir(String sehir) { this.sehir = sehir; }

    public String getIlce() { return ilce; }
    public void setIlce(String ilce) { this.ilce = ilce; }

    public String getTapuNo() { return tapuNo; }
    public void setTapuNo(String tapuNo) { this.tapuNo = tapuNo; }

    public Double getBrutM2() { return brutM2; }
    public void setBrutM2(Double brutM2) { this.brutM2 = brutM2; }

    public Double getNetM2() { return netM2; }
    public void setNetM2(Double netM2) { this.netM2 = netM2; }

    public String getDegerlemeRaporuLink() { return degerlemeRaporuLink; }
    public void setDegerlemeRaporuLink(String degerlemeRaporuLink) { this.degerlemeRaporuLink = degerlemeRaporuLink; }

    public KullanimDurumu getKullanimDurumu() { return kullanimDurumu; }
    public void setKullanimDurumu(KullanimDurumu kullanimDurumu) { this.kullanimDurumu = kullanimDurumu; }

    public LocalDate getEnSonDegerlemeTarihi() { return enSonDegerlemeTarihi; }
    public void setEnSonDegerlemeTarihi(LocalDate enSonDegerlemeTarihi) { this.enSonDegerlemeTarihi = enSonDegerlemeTarihi; }

    public BigDecimal getEnSonDegerlemeTutari() { return enSonDegerlemeTutari; }
    public void setEnSonDegerlemeTutari(BigDecimal enSonDegerlemeTutari) { this.enSonDegerlemeTutari = enSonDegerlemeTutari; }
}